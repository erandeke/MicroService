package com.callerService.hystrix.HystrixProjectImpl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HystrixProjectImplApplication {

	public static void main(String[] args) {
		SpringApplication.run(HystrixProjectImplApplication.class, args);
	}
}
