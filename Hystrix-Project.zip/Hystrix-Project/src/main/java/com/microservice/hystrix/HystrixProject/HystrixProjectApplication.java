package com.microservice.hystrix.HystrixProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HystrixProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(HystrixProjectApplication.class, args);
	}
}
